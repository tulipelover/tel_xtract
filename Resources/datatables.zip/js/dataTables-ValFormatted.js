jQuery.fn.dataTable.ext.type.order['file-size-pre'] = function ( data ) {
	var x = data.match( /^(\d+(?:\.\d+)?)\s*([a-z]+)/i );
	var x_unit;
	if (x) {
		x_unit = (/k[ob]/i.test(x[2]) ?
			1000 : (/ki[ob]/i.test(x[2]) ? 
			1024 : (/m[ob]/i.test(x[2]) ?
			1000000 : (/mi[ob]/i.test(x[2]) ?
			1048576 : (/g[ob]/i.test(x[2]) ?
			1000000000 : (/gi[ob]/i.test(x[2]) ?
			1073741824 : (/t[ob]/i.test(x[2]) ?
			1000000000000 : (/ti[ob]/i.test(x[2]) ? 
			1099511627776 : (/p[ob]/i.test(x[2]) ? 
			1000000000000000 : (/pi[ob]/i.test(x[2]) ? 
			1125899906842624 : (/z[ob]/i.test(x[2]) ? 
			1000000000000000000 : (/zi[ob]/i.test(x[2]) ? 
			1152921504606846976 : 1))))))))))));
	}
	else {
		return -1;
	}
	var val = x[1].replace(',','.');
	return parseFloat( val * x_unit, 10 );
};

jQuery.fn.dataTable.ext.type.order['intEsp-pre'] = function ( data ) {
	var val = data.replace(/ /g,'');
	return parseInt(val);
};

jQuery.fn.dataTable.ext.type.order['datefr-pre'] = function ( data ) {
	var a = data;
	if(a === "" || a==="~") {return "";}
	var aSplit = $.trim(a).split(' ');
	var aDate = new Array;
	var aTime;
	var aUTC;
	if(aSplit[0].indexOf("/") !== -1){
		bSplit = aSplit[0].split('/');
		aDate[0]=bSplit[0];
		aDate[1]=bSplit[1];
		aDate[2]=bSplit[2];
		if(aSplit.length >= 2){
			aTime = aSplit[1].split(':');
			if(aSplit.length == 3) {
				aUTC = aSplit[2];
			}
		}
	}
	else {
		aDate[0]=aSplit[1];
		aDate[1]=findMonth(aSplit[2]);
		aDate[2]=aSplit[3];
		if(aSplit.length >= 4){
			aTime = aSplit[4].split(':');
			if(aSplit.length == 5) {
				aUTC = aSplit[5];
			}
		}
	}
	var sign = 1;
	var aHDec = 0;
	var aMDec = 0;
	var aJDec = 0;
	if (typeof aUTC === 'undefined' || aUTC === ""){
		var x;
		if(typeof aTime === 'undefined' || aTime === ""){
			x = Date.UTC(parseInt(aDate[2]), (parseInt(aDate[1])-1), (parseInt(aDate[0])), 0,0,0);
		}
		else {
			x = Date.UTC(parseInt(aDate[2]), (parseInt(aDate[1])-1), (parseInt(aDate[0])), parseInt(aTime[0]), parseInt(aTime[1]), parseInt(aTime[2]));
		}
		return x;
	}
	else {
		if(aUTC.length > 3) {
			sign = parseFloat(aUTC.substr(3,1)+"1");
			if(aUTC.length > 6) {
				aHDec = parseFloat(aUTC.substr(4,2));
				aMDec = parseFloat(aUTC.substr(6));
			}
			else {
				aHDec = parseFloat(aUTC.substr(4));
			}
		}
		var min = parseInt(aTime[1])-(aMDec*sign);
		if (min<0) { 
			min+=60;
			aHDec-=1;
		}
		else if (min>=60){
			min-=60;
			aHDec+=1;
		}
		var h = parseInt(aTime[0])-(aHDec*sign);
		if (h<=-24){
			h+=24;
			aJDec-=1;
		}
		else if (h>=24){
			h-=24;
			aJDec+=1;
		}
		var x = Date.UTC(parseInt(aDate[2]), (parseInt(aDate[1])-1), (parseInt(aDate[0])+aJDec), h, min, parseInt(aTime[2]));
		return x;
	}
}

function findMonth(month) {
	var lmonth = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
	var lmonth2 = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
	for(var i in lmonth2){
		if(month === lmonth2[i]){
			return (parseInt(i)+1).toString();
		}
	}
	for(var i in lmonth){
		if(month === lmonth[i]){
			return (parseInt(i)+1).toString();
		}
	}
}


