function FenSize(){
	var x = $(window).width();
	var y = $(window).height();
	var sx = screen.width;
	var sy = screen.height;
	var w = parseInt((Math.min(x, parseInt(y*4/3)))*0.8);
	if (w<500){w=500};
	if(w>(sx*0.8)){w=parseInt(sx*0.8)};
	var h = parseInt(w*3/4);
	if(h>(sy*0.8)){h=parseInt(sy*0.8)};
	return {w:w, h:h};
}

$(document).ready(function() {
	$('h1').click(function () {
		if ($(this.childNodes[0]).hasClass('ouv')) {
			$(this.childNodes[0]).removeClass('ouv');
			$(this.childNodes[0]).addClass('clo');
		}
		else {
			$(this.childNodes[0]).removeClass('clo');
			$(this.childNodes[0]).addClass('ouv');
		}
		var ndiv = this.nextElementSibling;
		$(ndiv).toggle('blind',{direction: 'vertical'}, 500);
	});
	
	/*
	 *  Simple image gallery. Uses default settings
	 */
	var hreff;
	$('.fancybox')
		.attr('rel', 'gallery')
		.fancybox({
			openEffect  : 'elastic',
			closeEffect : 'elastic',
			nextEffect  : 'elastic',
			prevEffect  : 'elastic',
			//scrolling : false,
			//autoSize : true,
			beforeLoad: function() {
				var typ = $(this.element).data('typ');
				var width = $(this.element).data('width'); // get dimensions from data attributes
				var height = $(this.element).data('height');
				if (width === undefined || height === undefined) {
					var sz = FenSize();
					width = sz.w;
					height = sz.h;
				}
				var file = $(this.element).data('tit');
				if(typ === "video") {
					var hreff = this.href;
					this.href = "";
					this.type = 'inline';
					this.content = "<div><video width='"+width+"' height='" + height + "' autoplay='autoplay' controls='controls' autoplay>		<source src='"+hreff+"'> 	Your browser does not support the video tag.	</video></div>";
					this.title = "<span id='down' class='f-name' data-lien='"+hreff+"'></span>	<span class='f-name'><b>"+file+"</b></span>";
				}
				else if(typ === "audio") {
					var hreff = this.href;
					this.href = "";
					this.type = 'inline';
					this.content = "<div><audio width='400' height='30' controls='controls'><source src='"+hreff+"' /></audio></div>";
					this.title = "<span id='down' class='f-name' data-lien='"+hreff+"'></span>	<span class='f-name'><b>"+file+"</b></span>";
				}
			},
			afterLoad: function () {
			  var typ = $(this.element).data('typ');
			  var file = $(this.element).data('tit');
			  var width = $(this.element).data('width'); // get dimensions from data attributes
			  var height = $(this.element).data('height');
			  if (typ === "html" || typ === "pdf" || typ === "img") {
				this.title = "<span id='down' class='f-name' data-lien='"+this.href+"'></span>	<span class='f-name'><b>"+file+"</b><span>";
			  }
			  else if (typ === undefined) {
				var file = $(this.element).data('tit');
				var metadata = $(this.element).data('meta');
				var txt = "<div><b>"+file+"</b></div>";
				if(metadata !== undefined) {
					var blocd = metadata.split(";");
					txt += "<div><table cellpadding='1' cellspacing='0' border='0'><tbody>";
					for (i=0; i < blocd.length; i++){
						if(blocd[i] !== "") {
							var inf = blocd[i].split("|");
							txt += "<tr><td>" + inf[0] + " : </td><td>" + inf[1] + "</td></tr>";
						}
					}
					txt += "</tbody></table></div>";
				}
				this.title = txt;
			  }
			},
			helpers : {
				title: {
					type: 'outside',
					position: 'bottom'
				}
			},
			padding     : 10,
			margin      : [20, 60, 20, 60] // Increase left/right margin
		});
});