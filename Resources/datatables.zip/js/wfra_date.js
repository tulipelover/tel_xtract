/* Fonction de calcul des dates en prenant en compte les fuseaux horaires et le changement d'heure d'été (pour l'UE) */
var cTmz = '';
var cda = false;
var refD = {};
var lastTmsp = {};
var today = new Array();
var dt = new Date(Date.now());
today[0]=dt.getFullYear();
today[1]=dt.getMonth();
today[2]=dt.getDate();
	
function parse_date (d,obj){
	var dtxt;
	var tmsp;
	if(d==='') {
		return {
			tmsp: '',
			dtxt: ''
		};
	}
	var lmois = {'janv.':0,'févr.':1,'mars':2,'avril':3,'avr.':3,'mai':4,'juin':5,'juil.':6,'août':7,'sept.':8,'oct.':9,'nov.':10,'déc.':11};
	var moisl = {0:'janv.',1:'févr.',2:'mars',3:'avril',4:'mai',5:'juin',6:'juil.',7:'août',8:'sept.',9:'oct.',10:'nov.',11:'déc.'};
	var y;
	var m;
	var j;
	var h=0;
	var n=0;
	var i = d.indexOf('/');
	if(i>0){
		var htxt=' 00:00';
		var sd = d.split(" ");
		// traitement de la date
		var dd = sd[0].split('/');
		if(dd.length>2) {
			y = parseInt(dd[2]);
			m = parseInt(dd[1])-1;
			j = parseInt(dd[0]);
		}
		if (sd.length > 1) { // traitement de l'heure
			var td = sd[1].split(':');
			h=td[0];
			n=td[1];	
			htxt = " "+sd[1];
		}
		dtxt = j.toString().padStart(2, "0") + " " + moisl[m] + " " + y.toString().padStart(4, "0") + htxt;
	}
	else {
		dtxt = d;
		var sd = d.split(" ");
		// traitement de la date
		if (sd.length > 2) {
			j=sd[0];
			m = lmois[sd[1]];
			y = sd[2];
		}
		if (sd.length > 3) { // traitement de l'heure
			var td = sd[3].split(':');
			h=td[0];
			n=td[1];
			htxt = " "+sd[3];
		}
		dtxt = j.toString().padStart(2, "0") + " " + moisl[m] + " " + y.toString().padStart(4, "0") + htxt;
	}
	
	tmsp = Math.round(new Date(Date.UTC(y,m,j,parseInt(h),parseInt(n),0)).getTime()/1000);
	/*var tmzl = new Date(tmsp*1000).getTimezoneOffset();*/
	obj.datetimepicker('setDate',new Date(tmsp*1000));
	return {
		dtxt: dtxt,
		tmsp: tmsp
	};
}

function def_tmsp ( d, inst ) {
	// vérifie la structure de la date transmise
	if(d===undefined || d==='') {return ''; }
	var tmsp;
	var lbt = d.split(' ');
	if(d.length >= 3){
		var m = parseInt(inst.currentMonth)+1;
		var d1 = inst.currentYear + "-" + m + "-" +inst.currentDay;
		if(lbt.length >= 4) { d1 += " " +lbt[3];}
		if(lbt.length >= 5) { d1 += lbt[4];}
		if(lbt.length < 5){ // pas de fuseau horaire
			d1 += cTmz;
			if (cda) {
				tmsp = Date.parse(d1);
				// calcul de la période pour l'heure d'été
				// détermine date du dernier dimanche de mars
				var dpe = Date.parse(lastSunday(inst.currentYear,2)+" 01:00+0000");
				var fpe = Date.parse(lastSunday(inst.currentYear,9)+" 01:00+0000");
				if(tmsp >= dpe && tmsp < fpe) {
					tmsp -= 3600000;
				}
			}
			else {
				tmsp = Date.parse(d1);
			}
		}
		else {
			tmsp = Date.parse(d1);
		}
		return Math.trunc(tmsp/1000);
	}
	return undefined;
}

function lastSunday( y, m ) {
	var lastDay = [31,28,31,30,31,30,31,31,30,31,30,31];
	if (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) lastDay[2] = 29;
	var date = new Date(), month=m;
	date.setFullYear(y, m, lastDay[m]);
	date.setDate(date.getDate()-date.getDay());
	return date.toISOString().substring(0,10);
}

function tabfilter_date (otab, refT, iselected, iother, from_to, fbutton) {
	var r = parse_date(iselected.val(),iselected);
	var ltmsp = parseInt(iselected.attr('tmsp'));
	if((isNaN(ltmsp) || ltmsp === undefined || ltmsp !== r.tmsp) && r.dtxt !== ''){
		var dto = parseInt(iother.attr('tmsp'));
		if(((isNaN(r.tmsp) || r.tmsp === '') && r.dtxt !== '') || (!isNaN(dto) && r.tmsp < dto && r.dtxt !== '' && from_to === 1) || (!isNaN(dto) && r.tmsp > dto && r.dtxt !== '' && from_to === 0)){
			fbutton.css({"background-position-y":"0px", "cursor":"pointer"}).prop('disabled', false);
			iselected.css({"background-color":"#FFC9C9"});
			iselected.attr('tmsp','');
			return;
		}
		else if ((isNaN(r.tmsp) || r.tmsp === '') && r.dtxt === ''){
			iselected.css({"background-color":"#FFF"});
			iselected.attr('tmsp','');
		}
		else {
			fbutton.css({"background-position-y":"0px", "cursor":"pointer"}).prop('disabled', false);
			iselected.css({"background-color":"#CEF6FF"});
			iselected.attr('tmsp',r.tmsp);
			iselected.val(r.dtxt);
			var tmzl = new Date(r.tmsp*1000).getTimezoneOffset();
			if(from_to ===0) {
				var dt = new Date((r.tmsp+(tmzl*60))*1000 + 60000);
				iother.datetimepicker('option', 'minDate', dt );
				iother.datetimepicker('option', 'minDateTime', dt );
			}
			else {
				var dt = new Date((r.tmsp+(tmzl*60))*1000 - 60000);
				iother.datetimepicker('option', 'maxDate', dt );
				iother.datetimepicker('option', 'maxDateTime', dt );
			}
		}
		otab.draw();
		if(from_to===0){
			lastTmsp[refT+'from'] = r.tmsp;;
		}
		else {
			lastTmsp[refT+'to'] = r.tmsp;
		}
	}
}

$.fn.dataTableExt.afnFiltering.push(
	function( oSettings, aData, iDataIndex, oData, ix ) {
		var rT = oSettings.sTableId.substring(4);
		if(rT.substring(0,2) === "fF"){
			var ref = '#'+rT.substring(2);
			var dDeb = parseInt($(ref+'_from').attr('tmsp'));
			var dFin = parseInt($(ref+'_to').attr('tmsp'));
			var tmspdt;
			if(isNaN(parseInt(refD[rT.substring(2)]))){
				tmspdt = parseInt(oData[refD[rT.substring(2)]].timestamp);
			}
			else {
				tmspdt = parseInt(aData[refD[rT.substring(2)]]);
			}
			if (( (isNaN(dDeb) || dDeb === undefined) && (isNaN(dFin) || dDeb === undefined) ) ||
			( tmspdt <= dFin && isNaN(dDeb)) ||
			( tmspdt >= dDeb && isNaN(dFin)) ||
			(tmspdt <= dFin && tmspdt >= dDeb)){
				return true;
			}
			return false;
		}
		else {
			return true;
		}
	}
);