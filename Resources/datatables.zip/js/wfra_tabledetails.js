function formatN(val,nb){
	if(val>0){
		var r = "" + val;
		while (r.length < nb) {
			r = "0" + r;
		}
		return r;
	}
	return 0;
}

function fnFormatDetailsTab ( nTr, aData, Tabix ){
	var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:30px;">';
	var nbix = Tabix.length;
	var ExDt= 0;
	for(var i=0; i<nbix; i++) {
		var inf = Tabix[i][0].split('_');
		if (inf[0] === 'V'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += '; ';}
				txt += aData[Tabix[i][j+2]];
			}
			if(txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
		else if (inf[0] === 'S'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += ' ';}
				txt += aData[Tabix[i][j+2]];
			}
			if(txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
		else if (inf[0] === 'D'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += '; ';}
				if(j==1 && aData[Tabix[i][j+2]] !== '') {
					txt += ' [<i>' + aData[Tabix[i][j+2]] + '</i>]; ';
				}
				else {
					txt += aData[Tabix[i][j+2]];
				}
			}
			if(txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
		else if(inf[0] === 'T'){
			var txt ='';
			var bloc = aData[Tabix[i][2]].split('<td>');
			for (var j=1; j<bloc.length; j++){
				if(j>1){
					txt += '<td>'+bloc[j].split('</td>')[0]+'</td>';
				}
			}
			if(txt !== '') {
				sOut += '<tr>'+txt+'</tr>';
				ExDt = 1;
			}
		}
		else if(inf[0] === 'B'){
			var txt ='';
			var bloc = aData[Tabix[i][2]];
			if(bloc !== ''){
				sOut += '<tr><td colspan="2">'+bloc+'</td></tr>';
				ExDt = 1;
			}
		}
		else if (inf[0] === 'R'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if (aData[Tabix[i][j+2]] != ''){
					if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += '; ';}
					if(j>1) { txt += ' - ' + aData[Tabix[i][j+2]];}
					else if(j==1) { txt += ' [<i>' + aData[Tabix[i][j+2]] + '</i>]; ';}
					else { txt += aData[Tabix[i][j+2]];}
				}
			}
			if (txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
	}
	sOut += '</table>';
	if (ExDt == 1) { 
		return sOut;
	}
	else {
		return '<p>Aucune donnée complémentaire</p>';
	}
}

function defDetailsTab(Tabix){
	var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:30px;">';
	var nbix = Tabix.length;
	var ExDt= 0;
	for(var i=0; i<nbix; i++) {
		var inf = Tabix[i][0].split('_');
		if (inf[0] === 'V'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += '; ';}
				if(Tabix[i][j+2] !== undefined){ txt += Tabix[i][j+2]; }
			}
			if(txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
		else if (inf[0] === 'S'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += ' ';}
				if(Tabix[i][j+2] !== undefined){ txt += Tabix[i][j+2]; }
			}
			if(txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
		else if (inf[0] === 'D'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += '; ';}
				if(j==1 && Tabix[i][j+2] !== '' && Tabix[i][j+2] !== undefined) {txt += ' [<i>' + Tabix[i][j+2] + '</i>]; ';}
				else { if(Tabix[i][j+2] !== undefined){ txt += Tabix[i][j+2]; } }
			}
			if(txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
		else if(inf[0] === 'T'){
			var txt ='';
			var bloc = Tabix[i][2].split('<td>');
			for (var j=1; j<bloc.length; j++){
				if(j>1){
					txt += '<td>'+bloc[j].split('</td>')[0]+'</td>';
				}
			}
			if(txt !== '') {
				sOut += '<tr>'+txt+'</tr>';
				ExDt = 1;
			}
		}
		else if(inf[0] === 'B'){
			var txt ='';
			var bloc = Tabix[i][2];
			if(bloc !== ''){
				sOut += '<tr><td colspan="2">'+bloc+'</td></tr>';
				ExDt = 1;
			}
		}
		else if (inf[0] === 'R'){
			var txt = '';
			for (var j=0; j<parseInt(inf[1]); j++){
				if (Tabix[i][j+2] != ''){
					if(j>0 && txt.substring(txt.length - 2)!== ', ') { txt += '; ';}
					if(j>1) { txt += ' - ' + Tabix[i][j+2];}
					else if(j==1) { txt += ' [<i>' + Tabix[i][j+2] + '</i>]; ';}
					else { txt += Tabix[i][j+2];}
				}
			}
			if (txt !== '') {
				sOut += '<tr><td>'+Tabix[i][1]+'</td><td>'+txt+'</td></tr>';
				ExDt = 1;
			}
		}
	}
	sOut += '</table>';
	if (ExDt == 1) { 
		return sOut;
	}
	else {
		return '<p>Aucune donnée complémentaire</p>';
	}
}

function format_subTable (table_id, Tabix, nb, header) {
	var sOut="";
	if(Tabix !== undefined){
		sOut = defDetailsTab(Tabix);
	}
	if(nb>0){
		sOut +='		<div class="b_subtable">'+
		'<table id="'+table_id+'" class="display compact subtable" border="0" width="100%">'+
		'<thead><tr>'+
			header+
		'</tr></thead>'+
		'</table></div>';
	}
	if(sOut === undefined || sOut === '') {
		return '<p>Aucune donnée complémentaire</p>';
	}
	return sOut;
}